import { isAddressEqual, zeroAddress, type Address, type Hex } from 'viem';
import type { PripoClient } from './client.js';
import { contractCall, PripoConfigurationError } from './errors.js';
import { marketAbi } from './generated/abis.js';
import { WAD, type CloseParams, type CloseQuote, type LiquidateParams, type OpenParams, type OpenQuote, type ReadOptions } from './types.js';

export class Market {
  constructor(private readonly client: PripoClient, readonly address: Address) {}

  async quoteOpen(user: Address, size: bigint, options: ReadOptions = {}): Promise<OpenQuote> {
    const blockNumber = await this.client.block(options);
    const [avgFill, fee, marginRequired, newMark] = await contractCall(() => this.client.publicClient.readContract({
      address: this.address, abi: marketAbi, functionName: 'quoteOpenFor', args: [user, size], blockNumber,
    }));
    return { blockNumber, avgFill, fee, marginRequired, newMark };
  }

  async quoteClose(user: Address, sizeFraction: bigint, options: ReadOptions = {}): Promise<CloseQuote> {
    const blockNumber = await this.client.block(options);
    const [avgFill, fee, pnl, fundingOwed] = await contractCall(() => this.client.publicClient.readContract({
      address: this.address, abi: marketAbi, functionName: 'quoteClose', args: [user, sizeFraction], blockNumber,
    }));
    return { blockNumber, avgFill, fee, pnl, fundingOwed };
  }

  async position(user: Address, options: ReadOptions = {}) {
    const blockNumber = await this.client.block(options);
    return contractCall(() => this.client.publicClient.readContract({ address: this.address, abi: marketAbi,
      functionName: 'position', args: [user], blockNumber }));
  }

  async config(options: ReadOptions = {}) {
    const blockNumber = await this.client.block(options);
    return contractCall(() => this.client.publicClient.readContract({ address: this.address, abi: marketAbi,
      functionName: 'config', blockNumber }));
  }

  async health(user: Address, options: ReadOptions = {}) {
    const blockNumber = await this.client.block(options);
    const [healthWad, liquidatable] = await contractCall(() => this.client.publicClient.readContract({
      address: this.address, abi: marketAbi, functionName: 'health', args: [user], blockNumber }));
    return { blockNumber, healthWad, liquidatable };
  }

  async liquidationPrice(user: Address, options: ReadOptions = {}) {
    const blockNumber = await this.client.block(options);
    const [price, referenceKind, reason] = await contractCall(() => this.client.publicClient.readContract({
      address: this.address, abi: marketAbi, functionName: 'liquidationPriceInfo', args: [user], blockNumber }));
    return { blockNumber, price, referenceKind, reason };
  }

  async maxOpenable(user: Address, isLong: boolean, options: ReadOptions = {}) {
    const blockNumber = await this.client.block(options);
    return contractCall(() => this.client.publicClient.readContract({ address: this.address, abi: marketAbi,
      functionName: 'maxOpenable', args: [user, isLong], blockNumber }));
  }

  /** Reads every stable slot, including holes, at one block; never paginates by live positionCount. */
  async book(options: ReadOptions = {}) {
    const blockNumber = await this.client.block(options);
    const accounts = await contractCall(() => this.client.publicClient.readContract({ address: this.address,
      abi: marketAbi, functionName: 'positionAccounts', args: [0n, 128n], blockNumber }));
    const users = accounts.filter((account) => !isAddressEqual(account, zeroAddress));
    const positions = await Promise.all(users.map(async (user) => ({ user, ...await this.position(user, { blockNumber }) })));
    return { blockNumber, positions };
  }

  async prepareOpen(params: OpenParams) {
    if (params.size === 0n || params.limitPrice < 0n) {
      throw new PripoConfigurationError('Open requires a nonzero signed size and a nonnegative limit price');
    }
    const sender = this.client.sender();
    const user = params.user ?? sender;
    const blockNumber = await this.client.block();
    await this.client.validateMarket(this.address, blockNumber);
    const quote = await this.quoteOpen(user, params.size, { blockNumber });
    const external = await contractCall(() => this.client.publicClient.readContract({ address: this.address,
      abi: marketAbi, functionName: 'externalIndex', blockNumber }));
    let update: Hex = '0x';
    let value = 0n;
    if (external) {
      const [config, feedId] = await Promise.all([
        this.config({ blockNumber }),
        contractCall(() => this.client.publicClient.readContract({ address: this.address,
          abi: marketAbi, functionName: 'feedId', blockNumber })),
      ]);
      ({ update, value } = await this.client.pythUpdate(config.priceSource, feedId, blockNumber));
    }
    const owner = isAddressEqual(user, sender);
    const prepared = await this.client.prepare({ address: this.address, abi: marketAbi,
      functionName: owner ? 'open' : 'openFor', value,
      args: owner ? [params.size, params.limitPrice, update]
        : [user, params.size, params.limitPrice, update, params.marketProof ?? []],
    }, blockNumber);
    return { ...prepared, quote };
  }

  async open(params: OpenParams): Promise<Hex> {
    this.client.requireWallet();
    return this.client.broadcast(await this.prepareOpen(params));
  }

  async prepareClose(params: CloseParams) {
    if (params.sizeFraction <= 0n || params.sizeFraction > WAD || params.limitPrice < 0n) {
      throw new PripoConfigurationError('Close requires fraction in (0, WAD] and a nonnegative limit price');
    }
    const sender = this.client.sender();
    const user = params.user ?? sender;
    const blockNumber = await this.client.block();
    await this.client.validateMarket(this.address, blockNumber);
    const quote = await this.quoteClose(user, params.sizeFraction, { blockNumber });
    const owner = isAddressEqual(user, sender);
    // Runtime closes never read an oracle and reject native fees, even for Pyth markets.
    const prepared = await this.client.prepare({ address: this.address, abi: marketAbi,
      functionName: owner ? 'close' : 'closeFor', value: 0n,
      args: owner ? [params.sizeFraction, params.limitPrice, '0x']
        : [user, params.sizeFraction, params.limitPrice, '0x', params.marketProof ?? []],
    }, blockNumber);
    return { ...prepared, quote };
  }

  async close(params: CloseParams): Promise<Hex> {
    this.client.requireWallet();
    return this.client.broadcast(await this.prepareClose(params));
  }

  async liquidationContext(options: ReadOptions = {}) {
    const blockNumber = await this.client.block(options);
    const [config, index] = await Promise.all([
      this.config({ blockNumber }),
      contractCall(() => this.client.publicClient.readContract({ address: this.address,
        abi: marketAbi, functionName: 'indexPrice', blockNumber })),
    ]);
    const [price, updatedBlock, isExternal] = index;
    // Match MarketAccounting.isDegraded, including a stale cache before a status-changing poke.
    const degraded = config.status === 1 || (isExternal && blockNumber > updatedBlock + BigInt(config.degradeAfterBlocks));
    return { blockNumber, config, price, updatedBlock, isExternal, degraded };
  }

  async pendingAdl(user: Address, options: ReadOptions = {}) {
    const blockNumber = await this.client.block(options);
    return contractCall(() => this.client.publicClient.readContract({ address: this.address,
      abi: marketAbi, functionName: 'pendingAdl', args: [user], blockNumber }));
  }

  async fundingBinding(options: ReadOptions = {}) {
    const blockNumber = await this.client.block(options);
    return contractCall(() => this.client.publicClient.readContract({ address: this.address,
      abi: marketAbi, functionName: 'fundingBinding', blockNumber }));
  }

  /** No cached-health gate: a fresh oracle update may make an apparently healthy account liquidatable. */
  async prepareLiquidate(params: LiquidateParams) {
    const context = await this.liquidationContext();
    await this.client.validateMarket(this.address, context.blockNumber);
    let update: Hex = '0x';
    let value = 0n;
    if (context.isExternal && !context.degraded) {
      const feedId = await contractCall(() => this.client.publicClient.readContract({ address: this.address,
        abi: marketAbi, functionName: 'feedId', blockNumber: context.blockNumber }));
      ({ update, value } = await this.client.pythUpdate(context.config.priceSource, feedId,
        context.blockNumber, params.oracleUpdate));
    }
    return this.client.prepare({ address: this.address, abi: marketAbi, functionName: 'liquidate', value,
      args: params.adlCandidates === undefined ? [params.user, update] : [params.user, update, params.adlCandidates],
    }, context.blockNumber);
  }

  async liquidate(params: LiquidateParams): Promise<Hex> {
    this.client.requireWallet();
    return this.client.broadcast(await this.prepareLiquidate(params));
  }

  private async prepareMaintenance(functionName: string, args: readonly unknown[]) {
    const blockNumber = await this.client.block();
    await this.client.validateMarket(this.address, blockNumber);
    return this.client.prepare({ address: this.address, abi: marketAbi, functionName, args }, blockNumber);
  }

  prepareContinueAdl(user: Address, candidates: readonly Address[]) {
    return this.prepareMaintenance('continueAdl', [user, candidates]);
  }
  prepareCompleteAdl(user: Address, maxIterations = 64n) {
    if (maxIterations < 1n || maxIterations > 64n) throw new PripoConfigurationError('ADL iterations must be 1–64');
    return this.prepareMaintenance('completeAdl', [user, maxIterations]);
  }
  preparePoke() { return this.prepareMaintenance('poke', []); }
  async continueAdl(user: Address, candidates: readonly Address[]) {
    this.client.requireWallet();
    return this.client.broadcast(await this.prepareContinueAdl(user, candidates));
  }
  async completeAdl(user: Address, maxIterations = 64n) {
    this.client.requireWallet();
    return this.client.broadcast(await this.prepareCompleteAdl(user, maxIterations));
  }
  async poke() {
    this.client.requireWallet();
    return this.client.broadcast(await this.preparePoke());
  }
}
