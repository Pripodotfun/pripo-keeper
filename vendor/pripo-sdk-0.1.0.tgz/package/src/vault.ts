import { erc20Abi, type Address, type Hex } from 'viem';
import type { PripoClient } from './client.js';
import { contractCall } from './errors.js';
import { marginVaultAbi } from './generated/abis.js';
import type { OperatorPolicy, ReadOptions } from './types.js';

export class Vault {
  constructor(private readonly client: PripoClient, readonly address: Address) {}

  async asset(options: ReadOptions = {}) {
    const blockNumber = await this.client.block(options);
    return contractCall(() => this.client.publicClient.readContract({ address: this.address, abi: marginVaultAbi,
      functionName: 'token', blockNumber }));
  }

  /** Internal WAD, unlike deposit/withdraw inputs. */
  async freeBalance(user: Address, options: ReadOptions = {}) {
    const blockNumber = await this.client.block(options);
    return contractCall(() => this.client.publicClient.readContract({ address: this.address, abi: marginVaultAbi,
      functionName: 'freeBalance', args: [user], blockNumber }));
  }

  async operator(user: Address, operator: Address, options: ReadOptions = {}): Promise<OperatorPolicy> {
    const blockNumber = await this.client.block(options);
    const [expiry, maxNotionalPerTx, maxTotalNotional, usedNotional, marketsRoot, canClose] =
      await contractCall(() => this.client.publicClient.readContract({ address: this.address, abi: marginVaultAbi,
        functionName: 'operators', args: [user, operator], blockNumber }));
    return { expiry, maxNotionalPerTx, maxTotalNotional, usedNotional, marketsRoot, canClose };
  }

  /** Raw six-decimal token units; approval does not deposit or wait for a receipt. */
  async approveDeposit(amount: bigint): Promise<Hex> {
    this.client.requireWallet();
    const blockNumber = await this.client.block();
    const token = await this.asset({ blockNumber });
    return this.client.broadcast(await this.client.prepare({ address: token, abi: erc20Abi,
      functionName: 'approve', args: [this.address, amount] }, blockNumber));
  }

  private async write(functionName: string, args: readonly unknown[]): Promise<Hex> {
    this.client.requireWallet();
    const blockNumber = await this.client.block();
    return this.client.broadcast(await this.client.prepare({ address: this.address, abi: marginVaultAbi,
      functionName, args }, blockNumber));
  }

  /** Raw six-decimal token units, not WAD. */
  deposit(amount: bigint): Promise<Hex> { return this.write('deposit', [amount]); }
  /** Withdraws only the signing account's own free funds. */
  withdraw(amount: bigint): Promise<Hex> { return this.write('withdraw', [amount]); }
  /** Expiry is a block number; setting a policy resets its cumulative usage. */
  setOperator(operator: Address, policy: Omit<OperatorPolicy, 'usedNotional'>): Promise<Hex> {
    return this.write('setOperator', [operator, { ...policy, usedNotional: 0n }]);
  }
  revokeOperator(operator: Address): Promise<Hex> { return this.write('revokeOperator', [operator]); }
}
