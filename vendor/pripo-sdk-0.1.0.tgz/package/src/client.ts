import {
  encodeFunctionData, erc20Abi, getAddress, isAddressEqual,
  type Abi, type Address, type Hex,
} from 'viem';
import { marketAbi, marketFactoryAbi, marginVaultAbi, pythAdapterAbi } from './generated/abis.js';
import { contractCall, PripoConfigurationError } from './errors.js';
import { HermesClient } from './oracle.js';
import { Market } from './market.js';
import { Maintenance } from './maintenance.js';
import { Vault } from './vault.js';
import type { CreateMarketParams, PreparedTransaction, PripoClientOptions, ReadOptions } from './types.js';

/** Internal call description. Public methods select only implemented ABI entry points. */
export interface ContractCall {
  address: Address;
  abi: Abi;
  functionName: string;
  args: readonly unknown[];
  value?: bigint;
}

export class PripoClient {
  readonly publicClient: PripoClientOptions['publicClient'];
  readonly chain: PripoClientOptions['chain'];
  readonly vault: Vault;
  readonly maintenance: Maintenance;
  readonly factoryAddress: Address;
  private readonly walletClient;
  private readonly configuredAccount;
  private readonly oracle;
  private readonly pythAdapters: readonly Address[];
  private readonly gasBuffer: bigint;

  constructor(options: PripoClientOptions) {
    this.publicClient = options.publicClient;
    this.chain = options.chain;
    this.walletClient = options.walletClient;
    this.configuredAccount = options.account ?? options.walletClient?.account;
    this.factoryAddress = getAddress(options.factory);
    this.vault = new Vault(this, getAddress(options.vault));
    this.maintenance = new Maintenance(this);
    this.oracle = options.oracle ?? new HermesClient();
    this.pythAdapters = (options.pythAdapters ?? []).map((address) => getAddress(address));
    this.gasBuffer = options.gasBuffer ?? 10_000n;
    if (!Number.isSafeInteger(this.chain.id) || this.chain.id <= 0 || this.gasBuffer < 0n) {
      throw new PripoConfigurationError('Expected a positive chain ID and nonnegative gas buffer');
    }
    if (this.publicClient.chain && this.publicClient.chain.id !== this.chain.id) {
      throw new PripoConfigurationError('Public client chain differs from configured chain');
    }
  }

  market(address: Address): Market { return new Market(this, getAddress(address)); }

  async block(options: ReadOptions = {}): Promise<bigint> {
    return options.blockNumber ?? this.publicClient.getBlockNumber({ cacheTime: 0 });
  }

  sender(): Address {
    if (!this.configuredAccount) throw new PripoConfigurationError('An account is required to prepare transactions');
    return getAddress(typeof this.configuredAccount === 'string' ? this.configuredAccount : this.configuredAccount.address);
  }

  requireWallet(): void {
    if (!this.walletClient) throw new PripoConfigurationError('A wallet client is required to send transactions');
    this.sender();
  }

  async assertChain(): Promise<void> {
    const ids = await Promise.all([
      this.publicClient.getChainId(),
      ...(this.walletClient ? [this.walletClient.getChainId()] : []),
    ]);
    if (ids.some((id) => id !== this.chain.id)
      || (this.walletClient?.chain && this.walletClient.chain.id !== this.chain.id)) {
      throw new PripoConfigurationError(`RPC and wallet must use chain ${this.chain.id}`);
    }
  }

  /** @internal Prevent a configured deployment from silently trading through another vault/factory. */
  async validateMarket(address: Address, blockNumber: bigint): Promise<void> {
    const [vault, registered] = await contractCall(() => Promise.all([
      this.publicClient.readContract({ address, abi: marketAbi, functionName: 'vault', blockNumber }),
      this.publicClient.readContract({ address: this.factoryAddress, abi: marketFactoryAbi,
        functionName: 'isMarket', args: [address], blockNumber }),
    ]));
    if (!registered || !isAddressEqual(vault, this.vault.address)) {
      throw new PripoConfigurationError('Market does not belong to the configured factory and vault');
    }
  }

  /** @internal Only explicitly configured Pyth adapters get automatic updates. */
  async pythUpdate(adapter: Address, feedId: Hex, blockNumber: bigint, suppliedUpdate?: Hex) {
    if (!this.pythAdapters.some((known) => isAddressEqual(known, adapter))) {
      throw new PripoConfigurationError(`No Pyth configuration for adapter ${adapter}`);
    }
    const update = suppliedUpdate ?? await this.oracle.fetchUpdate([feedId]);
    const value = await contractCall(() => this.publicClient.readContract({ address: adapter,
      abi: pythAdapterAbi, functionName: 'updateFee', args: [update], blockNumber }));
    return { update, value };
  }

  /** @internal Simulation and estimation use the identical account, arguments and native value. */
  async prepare(call: ContractCall, blockNumber: bigint): Promise<PreparedTransaction> {
    await this.assertChain();
    const account = this.sender();
    const transaction = { ...call, account, value: call.value ?? 0n };
    await contractCall(() => this.publicClient.simulateContract(transaction));
    const estimate = await contractCall(() => this.publicClient.estimateContractGas(transaction));
    return {
      blockNumber,
      functionName: call.functionName,
      request: { account, chainId: this.chain.id, to: call.address,
        data: encodeFunctionData(call), value: transaction.value, gas: estimate + this.gasBuffer },
    };
  }

  /** @internal Called immediately after preparation by the SDK's write methods. */
  async broadcast(prepared: PreparedTransaction): Promise<Hex> {
    this.requireWallet();
    await this.assertChain();
    if (prepared.request.chainId !== this.chain.id || !isAddressEqual(prepared.request.account, this.sender())) {
      throw new PripoConfigurationError('Prepared transaction chain or sender differs from the client');
    }
    return contractCall(() => this.walletClient!.sendTransaction({ ...prepared.request,
      account: this.configuredAccount!, chain: this.chain }));
  }

  async listMarkets(options: ReadOptions & { offset?: bigint; limit?: number } = {}) {
    const offset = options.offset ?? 0n;
    const limit = options.limit ?? 50;
    if (offset < 0n || !Number.isInteger(limit) || limit < 1 || limit > 100) {
      throw new PripoConfigurationError('Market pages require offset >= 0 and limit 1–100');
    }
    const blockNumber = await this.block(options);
    const total = await contractCall(() => this.publicClient.readContract({ address: this.factoryAddress,
      abi: marketFactoryAbi, functionName: 'marketCount', blockNumber }));
    const length = Number(total > offset ? (total - offset < BigInt(limit) ? total - offset : BigInt(limit)) : 0n);
    const markets = await contractCall(() => Promise.all(Array.from({ length }, (_, i) =>
      this.publicClient.readContract({ address: this.factoryAddress, abi: marketFactoryAbi,
        functionName: 'markets', args: [offset + BigInt(i)], blockNumber }))));
    return { blockNumber, total, markets };
  }

  async prepareCreateMarket(params: CreateMarketParams) {
    const blockNumber = await this.block();
    const nullAdapter = await contractCall(() => this.publicClient.readContract({ address: this.factoryAddress,
      abi: marketFactoryAbi, functionName: 'nullAdapter', blockNumber }));
    const oracle = isAddressEqual(params.priceSource, nullAdapter)
      ? { update: '0x' as Hex, value: 0n }
      : await this.pythUpdate(params.priceSource, params.feedId, blockNumber);
    const predictedAddress = await contractCall(() => this.publicClient.readContract({ address: this.factoryAddress,
      abi: marketFactoryAbi, functionName: 'predictAddress', args: [params.symbol], blockNumber }));
    const prepared = await this.prepare({ address: this.factoryAddress, abi: marketFactoryAbi,
      functionName: 'createMarket', args: [params, oracle.update], value: oracle.value }, blockNumber);
    return { ...prepared, predictedAddress };
  }

  async createMarket(params: CreateMarketParams): Promise<Hex> {
    this.requireWallet();
    return this.broadcast(await this.prepareCreateMarket(params));
  }

  /** Seed bond is raw six-decimal USDC, not WAD. Approval is a separate transaction. */
  async approveSeedBond(amount: bigint): Promise<Hex> {
    this.requireWallet();
    const blockNumber = await this.block();
    const token = await this.vault.asset({ blockNumber });
    return this.broadcast(await this.prepare({ address: token, abi: erc20Abi,
      functionName: 'approve', args: [this.factoryAddress, amount] }, blockNumber));
  }
}

export function createPripoClient(options: PripoClientOptions): PripoClient { return new PripoClient(options); }
