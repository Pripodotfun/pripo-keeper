import { encodeAbiParameters, type Hex } from 'viem';
import { OracleUpdateError } from './errors.js';
import type { OracleUpdateProvider } from './types.js';

export interface HermesOptions {
  endpoint?: string;
  timeoutMs?: number;
  fetch?: typeof globalThis.fetch;
}

export class HermesClient implements OracleUpdateProvider {
  private readonly endpoint: string;
  private readonly timeoutMs: number;
  private readonly fetch: typeof globalThis.fetch;

  constructor(options: HermesOptions = {}) {
    this.endpoint = options.endpoint ?? 'https://pyth.dourolabs.app/hermes';
    this.timeoutMs = options.timeoutMs ?? 10_000;
    this.fetch = options.fetch ?? globalThis.fetch;
    const url = new URL(this.endpoint);
    if (!['http:', 'https:'].includes(url.protocol) || url.search || url.hash) {
      throw new OracleUpdateError('Hermes endpoint must be an HTTP(S) base URL without query or fragment');
    }
    if (!Number.isSafeInteger(this.timeoutMs) || this.timeoutMs <= 0) {
      throw new OracleUpdateError('Hermes timeout must be a positive integer');
    }
  }

  async fetchUpdate(feedIds: readonly Hex[]): Promise<Hex> {
    if (!feedIds.length || feedIds.some((id) => !/^0x[0-9a-fA-F]{64}$/.test(id))) {
      throw new OracleUpdateError('Expected at least one 32-byte feed ID');
    }
    const ids = [...new Set(feedIds.map((id) => id.slice(2).toLowerCase()))];
    const url = new URL(`${this.endpoint.replace(/\/+$/, '')}/v2/updates/price/latest`);
    for (const id of ids) url.searchParams.append('ids[]', id);
    url.searchParams.set('encoding', 'hex');
    url.searchParams.set('parsed', 'true');
    try {
      const response = await this.fetch(url, { signal: AbortSignal.timeout(this.timeoutMs) });
      if (!response.ok) throw new OracleUpdateError(`Hermes returned HTTP ${response.status}`);
      const body: unknown = await response.json();
      if (!body || typeof body !== 'object' || !('binary' in body) || !('parsed' in body)) {
        throw new OracleUpdateError('Malformed Hermes response');
      }
      const binary = body.binary;
      if (!binary || typeof binary !== 'object' || !('encoding' in binary) || binary.encoding !== 'hex'
        || !('data' in binary) || !Array.isArray(binary.data) || binary.data.length === 0) {
        throw new OracleUpdateError('Hermes did not return hex update data');
      }
      const payloads = binary.data.map((value: unknown): Hex => {
        if (typeof value !== 'string' || !/^(?:0x)?(?:[0-9a-fA-F]{2})+$/.test(value)) {
          throw new OracleUpdateError('Invalid Hermes update bytes');
        }
        return (value.startsWith('0x') ? value : `0x${value}`) as Hex;
      });
      const parsed = body.parsed;
      if (!Array.isArray(parsed) || ids.some((id) => !parsed.some(
        (entry: unknown) => !!entry && typeof entry === 'object' && 'id' in entry
          && typeof entry.id === 'string' && entry.id.replace(/^0x/, '').toLowerCase() === id,
      ))) throw new OracleUpdateError('Hermes response is missing a requested feed');
      return encodeAbiParameters([{ type: 'bytes[]' }], [payloads]);
    } catch (error) {
      if (error instanceof OracleUpdateError) throw error;
      throw new OracleUpdateError('Could not fetch Hermes update', { cause: error });
    }
  }
}
