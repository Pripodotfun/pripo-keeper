import {
  BaseError, ContractFunctionRevertedError, decodeErrorResult,
  type DecodeErrorResultReturnType, type Hex,
} from 'viem';
import { pripoErrorsAbi, marketFactoryAbi, marginVaultAbi, pythAdapterAbi } from './generated/abis.js';

const errorAbi = [...pripoErrorsAbi,
  ...marketFactoryAbi.filter((item) => item.type === 'error'),
  ...marginVaultAbi.filter((item) => item.type === 'error'),
  ...pythAdapterAbi.filter((item) => item.type === 'error'),
] as const;
export type PripoRevert = DecodeErrorResultReturnType<typeof errorAbi>;

export class PripoContractError extends Error {
  override readonly name = 'PripoContractError';
  constructor(readonly decoded: PripoRevert, cause?: unknown) {
    super(`Pripo reverted: ${decoded.errorName}(${(decoded.args ?? []).join(', ')})`, { cause });
  }
}

export class PripoConfigurationError extends Error {
  override readonly name = 'PripoConfigurationError';
}

export class OracleUpdateError extends Error {
  override readonly name = 'OracleUpdateError';
}

/** Unknown/provider errors remain intact, including the original cause. */
export function decodePripoError(data: Hex, cause?: unknown): PripoContractError | undefined {
  try { return new PripoContractError(decodeErrorResult({ abi: errorAbi, data }), cause); }
  catch { return undefined; }
}

export async function contractCall<T>(action: () => Promise<T>): Promise<T> {
  try { return await action(); }
  catch (error) {
    if (error instanceof BaseError) {
      const revert = error.walk((cause) => cause instanceof ContractFunctionRevertedError);
      if (revert instanceof ContractFunctionRevertedError && revert.raw) {
        const decoded = decodePripoError(revert.raw, error);
        if (decoded) throw decoded;
      }
    }
    throw error;
  }
}
