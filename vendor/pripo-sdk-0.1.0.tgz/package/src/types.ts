import type {
  Account, Address, Chain, ContractFunctionArgs, ContractFunctionReturnType,
  Hex, PublicClient, WalletClient,
} from 'viem';
import type { marketAbi, marketFactoryAbi, marginVaultAbi } from './generated/abis.js';

export const WAD = 10n ** 18n;
export type Position = ContractFunctionReturnType<typeof marketAbi, 'view', 'position'>;
export type MarketConfig = ContractFunctionReturnType<typeof marketAbi, 'view', 'config'>;
export type CreateMarketParams = ContractFunctionArgs<typeof marketFactoryAbi, 'payable', 'createMarket'>[0];
export type OperatorPolicy = ContractFunctionArgs<typeof marginVaultAbi, 'nonpayable', 'setOperator'>[1];

export interface OracleUpdateProvider {
  /** Return abi.encode(bytes[]), as accepted by Pripo's PythAdapter. */
  fetchUpdate(feedIds: readonly Hex[]): Promise<Hex>;
}

export interface PripoClientOptions {
  publicClient: PublicClient;
  chain: Chain;
  vault: Address;
  factory: Address;
  /** Explicit allowlist: only these adapter addresses receive Hermes payloads. */
  pythAdapters?: readonly Address[];
  walletClient?: WalletClient;
  account?: Account | Address;
  oracle?: OracleUpdateProvider;
  /** Fixed gas units added to the RPC estimate. Default 10,000; tune on Monad. */
  gasBuffer?: bigint;
}

export interface ReadOptions { blockNumber?: bigint }
export interface OpenQuote {
  blockNumber: bigint;
  avgFill: bigint;
  fee: bigint;
  marginRequired: bigint;
  newMark: bigint;
}
export interface CloseQuote {
  blockNumber: bigint;
  avgFill: bigint;
  fee: bigint;
  pnl: bigint;
  fundingOwed: bigint;
}
export interface OpenParams {
  size: bigint;
  limitPrice: bigint;
  /** Defaults to the signer; a different user selects the operator overload. */
  user?: Address;
  marketProof?: readonly Hex[];
}
export interface CloseParams {
  sizeFraction: bigint;
  limitPrice: bigint;
  user?: Address;
  marketProof?: readonly Hex[];
}
export interface LiquidateParams {
  user: Address;
  /** Omit to let the contract rank its complete book. An explicit [] can leave ADL pending. */
  adlCandidates?: readonly Address[];
  /** Optional already-fetched ABI-encoded Pyth update; the adapter still determines its exact fee. */
  oracleUpdate?: Hex;
}
export interface PreparedTransaction {
  /** Quote/read snapshot. Simulation and estimation use current RPC state. */
  blockNumber: bigint;
  functionName: string;
  request: {
    account: Address;
    chainId: number;
    to: Address;
    data: Hex;
    value: bigint;
    gas: bigint;
  };
}
