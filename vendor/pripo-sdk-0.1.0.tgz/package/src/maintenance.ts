import { isAddressEqual, type Address } from 'viem';
import type { PripoClient } from './client.js';
import { contractCall, PripoConfigurationError } from './errors.js';
import { feeSweeperAbi, insuranceBackstopAbi } from './generated/abis.js';

export class Maintenance {
  constructor(private readonly client: PripoClient) {}

  async prepareSweep(sweeper: Address, markets: readonly Address[]) {
    if (!markets.length || markets.length > 32 || new Set(markets.map((a) => a.toLowerCase())).size !== markets.length) {
      throw new PripoConfigurationError('Fee sweep requires 1–32 distinct markets');
    }
    const blockNumber = await this.client.block();
    const vault = await contractCall(() => this.client.publicClient.readContract({ address: sweeper,
      abi: feeSweeperAbi, functionName: 'vault', blockNumber }));
    if (!isAddressEqual(vault, this.client.vault.address)) throw new PripoConfigurationError('Sweeper vault mismatch');
    for (const market of markets) await this.client.validateMarket(market, blockNumber);
    return this.client.prepare({ address: sweeper, abi: feeSweeperAbi, functionName: 'sweep', args: [markets] }, blockNumber);
  }

  async sweep(sweeper: Address, markets: readonly Address[]) {
    this.client.requireWallet();
    return this.client.broadcast(await this.prepareSweep(sweeper, markets));
  }

  async prepareTopUp(backstop: Address, market: Address) {
    const blockNumber = await this.client.block();
    const vault = await contractCall(() => this.client.publicClient.readContract({ address: backstop,
      abi: insuranceBackstopAbi, functionName: 'vault', blockNumber }));
    if (!isAddressEqual(vault, this.client.vault.address)) throw new PripoConfigurationError('Backstop vault mismatch');
    await this.client.validateMarket(market, blockNumber);
    return this.client.prepare({ address: backstop, abi: insuranceBackstopAbi, functionName: 'topUp', args: [market] }, blockNumber);
  }

  async topUp(backstop: Address, market: Address) {
    this.client.requireWallet();
    return this.client.broadcast(await this.prepareTopUp(backstop, market));
  }
}
