# Contract integration notes

These notes apply to the ABI snapshot in `abi-manifest.json`. The contracts repository's `docs/implementation-notes.md` at that commit is the authoritative numerical reference. This repository builds independently of that checkout.

## Units and quotes

Prices, base sizes, margin, fee balances and operator notional limits are WAD (`10^18`). Token deposits, withdrawals and factory seed bonds use raw six-decimal USDC. Do not convert WAD through JavaScript floating-point numbers.

`quoteOpenFor(user, size)` returns the owner's incremental collateral requirement, including previewed funding effects. Operators must quote for the owner, not for their own signing address. Quotes do not enforce every execution gate; simulate the actual write with its proof and oracle payload.

`maxOpenable` is signed additional owner capacity at a particular block. An operator may have lower capacity because of policy limits. A successful quote or capacity read does not guarantee execution after state changes.

## Position book and health

Positions use stable slots, with zero-address holes after closes. `positionCount` counts live positions and cannot determine the highest occupied slot. The current book has at most 128 slots. Pin all pages and position reads to the same block.

`liquidationPriceInfo` returns `(price, referenceKind, reason)`. References none/index/TWAP are 0/1/2. Reasons are threshold/no position/pending ADL/inactive/funding-capacity binding/negative collateral/already unhealthy TWAP/no crossing, numbered 0–7. Zero price does not imply safety. Use the tagged reason and `health`.

Funding-capacity binding may make a position liquidatable even if ordinary equity health appears sufficient. Pending ADL freezes funding and blocks normal closes of the pending position. A keeper must account for the funding-capacity and ADL views, not just a price-crossing trigger.

## Oracle calls and policies

PythAdapter accepts `abi.encode(bytes[] signedUpdates)` and exact native value from `updateFee(update)`. Empty reads do not make a stale observation fresh. The current market's closes ignore update bytes and reject any native value, so a close must not depend on Hermes availability.

Operator proofs use the vault's double-hashed leaf `keccak256(bytes.concat(keccak256(abi.encode(market))))` with sorted Merkle pairs. A zero root permits any market. Both opening and closing consume exact curve quote notional; average fill multiplied back by size can differ through integer rounding. The SDK relies on actual simulated policy checks instead of approximating that amount.

Policy codes are: 1 expired/unregistered, 2 close forbidden, 3 invalid market proof, 4 per-transaction notional exceeded, 5 cumulative notional exceeded. Expiry is inclusive: a policy with `expiry <= block.number` fails. Resetting a policy resets consumed notional.

## Implemented versus planned interfaces

`marketAbi`, `marginVaultAbi`, `marketFactoryAbi`, `pythAdapterAbi`, `nullAdapterAbi`, and `feeSweeperAbi` describe implemented contracts. Core/interface ABIs provide smaller surfaces. `plannedMarketAbi` and `resolverAbi` include future declarations and must not be treated as deployed functionality.

Low-level ABIs also expose liquidation, ADL continuation, terminal settlement, funding-capacity, fee, and governance functions. This SDK's first typed layer does not yet wrap those workflows. Market creation is performed by the signing account and cannot be delegated through a user's trading operator policy.
