# @pripo/sdk

Standalone TypeScript SDK for Pripo perpetual markets. This repository owns the SDK and its release lifecycle. The `pripo-contract` repository owns Solidity, deployments, and canonical JSON ABIs. Indexer, keeper, MCP server, and frontend will consume SDK releases from their own repositories.

Version 0.1.0 is local and private; it has not been published to npm. It supports exact contract quotes, market/position reads, owner and operator trading, Pyth updates, vault deposits/withdrawals, operator policies, market creation, and keeper liquidation/ADL and maintenance calls. It exports compiled ESM and TypeScript declarations, with raw ABIs at `@pripo/sdk/abis`.

## Development

Requires Node 22+, npm, and Python 3 for ABI synchronization.

```sh
npm ci
npm run check        # typecheck, deterministic RPC tests, and package build
npm pack --dry-run   # inspect the distributable package
```

Use `npm pack` to create a local tarball for another repo until a package release is published. A consumer does not need a contracts checkout or a sibling workspace.

## Connect and read

Supply verified deployment addresses and an explicit viem chain. No deployment address, RPC credential, or private key is bundled.

```ts
import { createPripoClient, WAD, type PripoClientOptions } from '@pripo/sdk';
import type { Address } from 'viem';

async function inspect(options: PripoClientOptions, marketAddress: Address, user: Address) {
  const pripo = createPripoClient(options);
  const market = pripo.market(marketAddress);
  const quote = await market.quoteOpen(user, WAD);
  const health = await market.health(user, { blockNumber: quote.blockNumber });
  const liquidation = await market.liquidationPrice(user, { blockNumber: quote.blockNumber });
  return { quote, health, liquidation };
}
```

Only `publicClient`, `chain`, `vault`, and `factory` are needed for reads. Add `walletClient` and either its hoisted account or an explicit `account` for writes. Both viem local accounts and connected JSON-RPC wallets are supported; the caller owns key storage and signing. A read-only client with an explicit account can prepare transactions without signing them.

`listMarkets({ offset, limit, blockNumber })` pages the factory, up to 100 entries per request. `market.book()` reads the complete 128-slot book at one block and skips empty slots. Explicit `blockNumber` arguments pin related reads; the RPC must support those historical calls.

## Trading and transaction lifecycle

```ts
const market = pripo.market(marketAddress);
const prepared = await market.prepareOpen({ size, limitPrice });
console.log(prepared.quote, prepared.request.gas);

// Rebuilds the quote/update/simulation immediately before requesting a signature.
const hash = await market.open({ size, limitPrice });
const receipt = await publicClient.waitForTransactionReceipt({ hash });
if (receipt.status !== 'success') throw new Error('Trade reverted after simulation');
```

`open` and `close` read exact contract quotes, check market membership in the configured deployment, simulate the actual call, estimate gas, and then submit identical calldata and native value. Simulation/estimation failure prevents submission. The RPC and wallet chain IDs must match configuration. Quote snapshots include their block number; simulation and gas estimation use current state, so a quote is not a promise about the included trade. State, funding, oracle inputs and operator policy can change before inclusion.

Every trade requires an explicit WAD `limitPrice`: buys specify the maximum average fill; sells specify the minimum. Opening a long and closing a short are buys. Closing a long and opening a short are sells. A zero sell limit explicitly accepts any fill, including dust with zero proceeds. Size is signed WAD base units; closing uses a WAD fraction (`WAD` means a full close).

Prepared requests are inspection artifacts, with no signature or private key. Prefer `open`/`close` to sending an old prepared request; they fetch a new oracle payload and repeat simulation. Sending manually requires the caller to refresh and simulate again. SDK writes return a transaction hash, not confirmation. Wait for a successful receipt before dependent approvals, deposits or trades. Concurrent signing/nonces are caller-managed in this first version.

Gas is estimated for the exact call and a configurable fixed `gasBuffer` is added (default 10,000 units). This is an initial buffer, not a validated Monad gas recommendation. Monad charges for the gas limit; target-chain measurements are still needed to tune the buffer. See [Monad gas pricing](https://docs.monad.xyz/developer-essentials/gas-pricing) and [viem simulation](https://viem.sh/docs/contract/simulateContract).

## Oracle and operator behavior

For oracle-fed opens and creation, list deployed Pyth adapter addresses in `pythAdapters`. The SDK reads the feed ID, fetches the [Hermes update](https://docs.pyth.network/price-feeds/core/fetch-price-updates), ABI-encodes `bytes[]`, queries the adapter's `updateFee`, and forwards that exact native value. Unknown adapter types fail explicitly. Override `oracle` with an `OracleUpdateProvider`, or construct `HermesClient` with an endpoint, timeout, and custom fetch implementation.

Oracle-less opens send empty update bytes and zero value. **All closes do the same, including closes on Pyth markets:** the implemented runtime never reads an oracle on close and rejects native value. This follows the contract runtime, which differs from the early spec's close-update description.

Operators use the same methods with `user` set to the position owner and `marketProof` for a restricted market allowlist. The SDK selects the five-argument `openFor`/`closeFor` overload and quotes for the owner. Simulation runs the contract's actual policy checks, including expiry, close permission, Merkle proof, per-transaction notional, and cumulative usage. Both opens and closes consume exact curve quote notional. Policy expiry is a **block number**, not a timestamp.

`PripoContractError.decoded` is a discriminated custom-error result, including `PolicyViolation` codes 1–5. The original error is retained as `cause`; unrecognized provider errors are preserved. `market.liquidationPrice()` deliberately returns the tagged `liquidationPriceInfo` result: a scalar price of zero does not establish safety.

## Vault and creation

- `vault.approveDeposit`, `deposit`, and `withdraw` use raw six-decimal USDC units. `freeBalance` returns WAD. Wait for approval confirmation before depositing.
- `vault.setOperator` uses WAD notional limits and resets usage to zero; `revokeOperator` revokes that signer. Withdrawals always act on the signer's own account.
- `approveSeedBond` approves the factory separately, in raw USDC. `prepareCreateMarket` simulates creation and returns a predicted address; `createMarket` submits. Confirm the actual created address from the receipt's `MarketCreated` event. Governance changes can alter predictions before inclusion.
- Oracle-less creation uses the factory's canonical null adapter and a zero feed ID. External creation requires an approved/listed feed and a configured Pyth adapter. The SDK does not list feeds or change governance configuration.

See [contract integration notes](docs/contracts.md) and the compiled [deposit/trade example](examples/trade.ts).

## ABI versions across repositories

`abi-manifest.json` records the contracts commit and SHA-256 of each original JSON ABI. Bindings are checked in. To deliberately upgrade them:

```sh
# First build/export/commit canonical ABIs in the contracts repository.
npm run sync:abis -- --contracts /path/to/pripo-contract --ref <contracts-commit>
npm run sync:abis -- --contracts /path/to/pripo-contract --ref <contracts-commit> --check
npm run check
```

Synchronization reads committed files using `git show`; uncommitted contracts changes cannot silently enter a release. Review ABI changes and publish a new SDK version before upgrading consumers. `plannedMarketAbi` and `resolverAbi` expose roadmap declarations only; SDK write methods use concrete implemented ABIs.

## Local end-to-end verification

Build the ABI-pinned contracts checkout with Foundry, then:

```sh
PRIPO_CONTRACTS=/path/to/pripo-contract npm run test:integration
```

The test starts its own loopback Anvil, links and deploys the actual factory/vault/market libraries with a mock USDC, and exercises creation, approval, deposit, owner/operator open/close, real policy rejection, and withdrawal. It terminates its node afterward. It never uses a configured external RPC or a real key. This is local EVM coverage; signed Pyth integration and Monad fee/finality behavior remain target-chain validation work.

## Keeper methods

`market.liquidationContext()` pins the market config, external-index flag, index block and degradation predicate to one block. `pendingAdl(user)` and `fundingBinding()` expose recovery state. Use the boolean from `health()` alongside the tagged `liquidationPrice()` result; a price threshold alone misses funding and negative-collateral liquidations.

```ts
const prepared = await market.prepareLiquidate({ user });
// A keeper persists, signs and reconciles prepared.request with its own nonce journal.
// With a wallet client, market.liquidate({ user }) submits directly instead.
await market.prepareCompleteAdl(user, 64n);
await market.preparePoke();
await pripo.maintenance.prepareSweep(feeSweeperAddress, [marketAddress]);
await pripo.maintenance.prepareTopUp(backstopAddress, marketAddress);
```

Liquidation on an external market fetches a fresh Pyth update and its exact adapter fee unless the runtime's degradation predicate is true. Degraded and oracle-less liquidations send empty bytes and zero value. Preparation deliberately does not reject a liquidation using cached health: the fresh price used by simulation may change eligibility. `oracleUpdate` optionally supplies already-fetched ABI-encoded update bytes; the adapter allowlist and exact fee lookup still apply.

Omitting `adlCandidates` uses the runtime's automatic full-book ranking. An explicit `[]` selects the explicit-candidate overload and can leave ADL pending. `prepareContinueAdl(user, candidates)` is immediate; `prepareCompleteAdl(user, iterations)` invokes the contract's delayed fallback, accepts 1–64 slot visits, and exposes `AdlFallbackNotReady` before the deadline. The SDK does not sort candidates or infer eligibility. Sending counterparts are `continueAdl`, `completeAdl`, `poke`, `maintenance.sweep` and `maintenance.topUp`.

Fee sweeps require 1–32 distinct markets. Maintenance methods validate the target's vault and each market's configured factory membership before simulation. `topUp` sweeps excess market insurance into the shared backstop; it does not transfer keeper collateral.

Next increments: live Monad/Pyth keeper validation, then the independent Envio indexer and MCP consumers. Resolver write helpers depend on a deployed implementation.
