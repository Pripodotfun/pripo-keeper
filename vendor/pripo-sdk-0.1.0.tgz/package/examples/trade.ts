import { createPripoClient, type PripoClientOptions } from '../src/index.js';
import type { Address, Hex } from 'viem';

/** Caller supplies the signer, deployment, amounts and price bound; nothing runs on import. */
export async function depositAndOpen(
  options: PripoClientOptions,
  marketAddress: Address,
  depositRawUsdc: bigint,
  signedSizeWad: bigint,
  limitPriceWad: bigint,
) {
  const pripo = createPripoClient(options);
  const confirm = async (hash: Hex) => {
    const receipt = await options.publicClient.waitForTransactionReceipt({ hash });
    if (receipt.status !== 'success') throw new Error(`Transaction reverted: ${hash}`);
    return receipt;
  };
  await confirm(await pripo.vault.approveDeposit(depositRawUsdc));
  await confirm(await pripo.vault.deposit(depositRawUsdc));
  return confirm(await pripo.market(marketAddress).open({ size: signedSizeWad, limitPrice: limitPriceWad }));
}
